import 'package:flutter/material.dart';

//Paleta principal
class paleta_Principal{
  Color marrom = const Color.fromRGBO(69, 43, 52, 10);
  Color lumber = const Color.fromRGBO(255, 223, 211, 10);
  Color branco = Colors.white;
  Color rosaPastel = Color.fromRGBO(255,179,186,1);
}
class paleta_Opacos{
  Color marromOpaque = const Color.fromRGBO(69, 43, 52, 90);
  Color lumberOpaque = const Color.fromRGBO(255, 223, 211, 90);
}

//Cores para teste
class paleta_Testagem{
  Color TesteRed = Colors.red;
  Color TesteYellow = Colors.yellow;
  Color TesteGreen = Colors.green;
}
