import 'package:flutter/material.dart';
import 'Login/LoginScreen.dart';

void main() {
  runApp(MaterialApp(
    home: LoginScreen(),
  ));
}