import 'package:flutter/material.dart';
import 'Configurations/ConfigScreen.dart';
import 'Listas/ListsScreen.dart';
import 'Home/HomeScreen.dart';
import 'Login/LoginScreen.dart';

class AppBar_Bottom_Class extends StatefulWidget {
  const AppBar_Bottom_Class({Key? key}) : super(key: key);
  @override
  _AppBar_Bottom_ClassState createState() => _AppBar_Bottom_ClassState();
}

class _AppBar_Bottom_ClassState extends State<AppBar_Bottom_Class> {
  static const TextStyle optionStyle = TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  //BottomNavBar handling
  int _selectedIndex = 0;
  final _widgetOptions = [
    new HomeScreen(),
    new ListsScreen(),
    new ConfigScreen(),
  ];
  final widgetTitle = ["Home","Listas", "Configuracoes"];
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //Logo
        title: Image.asset(
            'assets/images/logo_transparent.png',
            fit: BoxFit.contain,
            height: 150,
        ),
        toolbarHeight: 60,
        flexibleSpace: Container(
          color: const Color.fromRGBO(69, 43, 52, 10),        //marrom
        ),
      ),
      body: Center(
             child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.view_list),
            label: "Listas",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: "Configurações",
          ),
        ],
        currentIndex: _selectedIndex,
        unselectedItemColor: Color.fromRGBO(249, 249, 249, 50), //off white
        selectedItemColor: Color.fromRGBO(255,179,186,1),       //rosa pastel
        backgroundColor: Color.fromRGBO(69, 43, 52, 10),        //marrom
        onTap: _onItemTapped,
      ),
    );
  }
}

