import 'package:flutter/material.dart';
import 'package:lysta_p/Listas/Cards/ItemCard.dart';
import 'Cards/AddNewItemCard.dart';

class ListsScreen extends StatefulWidget {
  @override
  _ListsScreenState createState() => _ListsScreenState();
}

class _ListsScreenState extends State<ListsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(255, 223, 211, 10), //Lumber (pastel),
      body: Center(
        child: Container(
            child: Stack(
              fit: StackFit.expand,
              alignment: AlignmentDirectional.bottomCenter,
              children: <Widget>[
                //Fundo
                Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      opacity: 0.3,
                      image: AssetImage('assets/images/logo_transparent.png'),
                      fit: BoxFit.contain,
                    ),
                  )
                ),
                //Scrollable
                SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      //Texto -> "Suas Listas"
                      Row(
                        children: [
                          Spacer(),
                          const Text("Suas listas",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Roboto',
                              letterSpacing: 0.5,
                              fontSize: 40,
                            ),
                          ),
                          Spacer()
                        ],
                      ),
                      //Cards de listas criadas
                      Column(
                        children: <Widget>[
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          ItemCard(),
                          AddNewItemCard()
                        ],
                      ),
                    ]
                  )
                )
              ]
            )
        ),
      ),
    );
  }
}

