import 'package:flutter/material.dart';
import 'Cards/ItemCard.dart';

class Lista extends StatefulWidget {
  @override
  _ListaState createState() => _ListaState();
}

class _ListaState extends State<Lista> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
            color: Color.fromRGBO(125, 48, 184, 60), //roxo
            //color: Color.fromRGBO(255, 223, 211, 10), //Lumber (pastel)
            child: Stack(
                fit: StackFit.expand,
                alignment: AlignmentDirectional.bottomCenter,
                children: <Widget>[
                  Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          opacity: 0.3,
                          image: AssetImage('assets/images/logo_transparent.png'),
                          fit: BoxFit.contain,
                        ),
                      )
                  ),
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        ItemCard(),
                      ],
                    ),
                  )
                ]
            )
        ),
      ),
    );
  }
}

