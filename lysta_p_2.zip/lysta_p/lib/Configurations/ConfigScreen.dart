import 'package:flutter/material.dart';
import 'package:lysta_p/Listas/Cards/ItemCard.dart';
import '../Home/Cards/HomeCard.dart';

class ConfigScreen extends StatefulWidget {
  @override
  _ConfigScreenState createState() => _ConfigScreenState();
}

class _ConfigScreenState extends State<ConfigScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(255, 223, 211, 10), //Lumber (pastel),
      body: Center(
        child: Stack(
          children: [
            Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    opacity: 0.3,
                    image: AssetImage('assets/images/logo_transparent.png'),
                    fit: BoxFit.contain,
                  ),
                )
            ),
            Column(
              children: [
                Row(
                  children: [
                    const Text("App",
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Roboto',
                        letterSpacing: 0.5,
                        fontSize: 50,
                      ),
                    ),
                  ],
                ),
                Positioned(
                  top: 200,
                  left: 0,
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.only(left: 20, right: 20, top: 5, bottom: 20),
                    width: MediaQuery.of(context).size.width,
                    decoration: const BoxDecoration(
                        color: const Color.fromRGBO(69, 43, 52, 90),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text("App",
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Roboto',
                                  letterSpacing: 0.5,
                                  fontSize: 50,
                                ),
                              ),
                            ],
                          ),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                ItemCard(),
                                ItemCard(),
                                ItemCard(),
                                ItemCard(),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            )
          ],
        )
      ),
    );
  }
}
/*
Positioned(
                  top: 200,
                  left: 0,
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.only(left: 20, right: 20, top: 30),
                    width: MediaQuery.of(context).size.width,
                    height: 200,
                    decoration: const BoxDecoration(
                        color: const Color.fromRGBO(69, 43, 52, 90),
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30)
                        )
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                ItemCard(),
                                ItemCard(),
                                ItemCard(),
                                ItemCard(),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
 */