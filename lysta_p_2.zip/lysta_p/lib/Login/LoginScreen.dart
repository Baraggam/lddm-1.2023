import '../AppBar_Bottom_Class.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 120,
        flexibleSpace: Container(
          //color: const Color.fromRGBO(230, 138, 46, 10),        //laranja
          //color: const Color.fromRGBO(255, 83, 71, 108),        //roxo
          color: const Color.fromRGBO(69, 43, 52, 10),            //marrom
        ),
      ),
      //backgroundColor: const Color.fromRGBO(69, 43, 52, 10),    //marrom
      //backgroundColor: Color.fromARGB(255, 8, 6, 6),            //preto
      body: Center(
        //Titulo
        child: Container(
          //color: Colors.white,
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: const [
                  Text(
                    'Bem-vindo ao Lysta+',
                    style: TextStyle(
                      //para dark
                      //color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Roboto',
                      letterSpacing: 0.5,
                      fontSize: 50,
                    ),
                  ),
                ],
              ),
              //Email+senha
              Column(
                children: [
                  Column(
                    children: const [
                      //Apenas texto (a ser discutido)
                      //Text("email:",
                      //    style: TextStyle(
                      //        fontFamily: 'Roboto',
                      //        fontSize: 25,
                      //        //color: Colors.white
                      //    )
                      //),
                      SizedBox(
                        width: 340,
                        height: 50,
                        child: TextField(
                          obscureText: false,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Email',
                          ),
                        ),
                      ),
                    ],
                  ),
                  //Senha
                  Column(
                    children: const [
                      //Apenas texto (a ser discutido)
                      Text('senha:',
                          style: TextStyle(
                              fontFamily: 'Roboto',
                              fontSize: 25,
                              //gambiarra para liberar espaço
                              //tentei com spacer mas nao consegui
                              //a ser corrigido
                              color: Colors.white24,
                          )
                      ),
                      SizedBox(
                        width: 340,
                        height: 50,
                        child: TextField(
                          obscureText: true,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Senha',
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              //Button Login
              Column(
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(horizontal: 150, vertical: 20),
                      backgroundColor: Colors.red,
                    ),
                    onPressed: (){
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AppBar_Bottom_Class()
                          ),
                      );
                    },
                    child: const Text('Login',
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          color: Colors.white
                        )
                    ),
                  )
                ],
              ),
              //Esqueceu+Termos
              Column(
                children: [
                  Column(
                    children: const [
                      Text('Cadastre-se',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            color: Colors.indigoAccent,
                            decoration: TextDecoration.underline,
                          )
                      )
                    ],
                  ),
                  Column(
                    children: const [
                      Text('Esqueceu a senha?',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            color: Colors.indigoAccent,
                            decoration: TextDecoration.underline,
                          )
                      )
                    ],
                  ),
                  Column(
                    children: const [
                      Text('Termos de privadidade',
                          style: TextStyle(
                            fontFamily: 'Roboto',
                            color: Colors.indigoAccent,
                            decoration: TextDecoration.underline,
                          )
                      )
                    ],
                  ),
                ],
              ),
            ],
          )
        )
      ),
    );
  }
}
