import 'package:flutter/material.dart';

class HomeCard extends StatelessWidget {
  const HomeCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        color: Color.fromRGBO(255, 223, 211, 90), //Lumber (pastel)
        elevation: 4,
        shape: RoundedRectangleBorder(
          side: BorderSide(),
          borderRadius: const BorderRadius.all(Radius.circular(10)),
        ),
        child: SizedBox(
          width: 350,
          height: 100,
          child:
          Row(
            children: [
              Column(
                children: [
                  Spacer(),
                  const Text("  Compras do mês",
                    style: TextStyle(
                        color: const Color.fromRGBO(69, 43, 52, 10),        //marrom
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Roboto',
                        letterSpacing: 0.5,
                        fontSize: 20
                    ),
                  ),
                  Spacer()
                ],
              ),
              Spacer(),
              Column(
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20), // Image border
                        child: SizedBox.fromSize(
                          size: Size.fromRadius(48), // Image radius
                          child: Image.asset('assets/images/no-image.png',
                              fit: BoxFit.cover),
                        ),
                      )
                    ],
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}