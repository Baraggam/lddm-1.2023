import 'package:flutter/material.dart';
import '../Listas/Cards/ItemCard.dart';
import 'Cards/HomeCard.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(255, 223, 211, 10), //Lumber (pastel),
      body: Center(
        child: Container(
          child: Stack(
              fit: StackFit.expand,
              alignment: AlignmentDirectional.bottomCenter,
              children: <Widget>[
                //Fundo
                Container(
                    decoration: const BoxDecoration(
                      image: DecorationImage(
                        opacity: 0.3,
                        image: AssetImage('assets/images/logo_transparent.png'),
                        fit: BoxFit.contain,
                      ),
                    )
                ),
                //body
                SingleChildScrollView(
                  //Encapsulamento principal
                  child: Column(
                    children: <Widget>[
                      //Listas Favoritas
                      Container(
                          padding: const EdgeInsets.only(left: 0, right: 0, top: 15, bottom: 0),
                          child: Column(
                            children: <Widget>[
                              //Texto -> "Listas Fav"
                              Row(
                                  children: [
                                    const Text(" Lista Favoritas",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Roboto',
                                          letterSpacing: 0.5,
                                          fontSize: 40
                                      ),
                                    ),
                                    Spacer(),
                                  ]
                              ),
                              //Cards Favoritos
                              Column(
                                children: <Widget>[
                                  HomeCard(),
                                  HomeCard(),
                                  HomeCard(),
                                ],
                              )
                            ],
                          )
                      ),
                      //Sugestoes
                      Container(
                        padding: const EdgeInsets.only(left: 0, right: 0, top: 20, bottom: 0),
                        child: Column(
                          children: [
                            //Texto -> "Sugestoes"
                            Row(
                              children: [
                                const Text(" Sugestões",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Roboto',
                                      letterSpacing: 0.5,
                                      fontSize: 40
                                  ),
                                ),
                              ],
                            ),
                            //Sugestoes de listas
                            Positioned(
                              top: 200,
                              left: 0,
                              bottom: 0,
                              right: 0,
                              child: Container(
                                padding: const EdgeInsets.only(left: 20, right: 0, top: 0, bottom: 5),
                                width: MediaQuery.of(context).size.width,
                                child: SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      //Texto -> sugestoes de listas
                                      Row(
                                        children: [
                                          const Text("Crie mais listas",
                                            style: TextStyle(
                                              fontWeight: FontWeight.w800,
                                              fontFamily: 'Roboto',
                                              letterSpacing: 0.5,
                                              fontSize: 30,
                                            ),
                                          ),
                                        ],
                                      ),
                                      //Cards com sugestoes de listas
                                      SingleChildScrollView(
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: [
                                            ItemCard(),
                                            ItemCard(),
                                            ItemCard(),
                                            ItemCard(),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            //Sugestoes de receitas com ingredientes
                            Positioned(
                              top: 200,
                              left: 0,
                              bottom: 0,
                              right: 0,
                              child: Container(
                                padding: const EdgeInsets.only(left: 20, right: 0, top: 0, bottom: 15),
                                width: MediaQuery.of(context).size.width,
                                child: SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      //Texto -> "Receitas do dia"
                                      Row(
                                        children: [
                                          const Text("Receitas do dia",
                                            style: TextStyle(
                                              fontWeight: FontWeight.w800,
                                              fontFamily: 'Roboto',
                                              letterSpacing: 0.5,
                                              fontSize: 30,
                                            ),
                                          ),
                                        ],
                                      ),
                                      //Cards com receitas populares
                                      SingleChildScrollView(
                                        scrollDirection: Axis.horizontal,
                                        child: Row(
                                          children: [
                                            ItemCard(),
                                            ItemCard(),
                                            ItemCard(),
                                            ItemCard(),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],//Children
                  ),
                )
              ]
          ),
        ),
      ),
    );
  }
}